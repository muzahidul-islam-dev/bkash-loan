<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">Payment Configuration</h4>
                    <br>
                    <form action="<?php echo e(Route('payment.save')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3 row">
                            <label for="username" class="col-md-1 col-form-label">Username</label>
                            <div class="col-md-11">
                                <input class="form-control" value="<?php echo e(old('username', $paymentData?->username)); ?>"
                                    placeholder="Username" name="username" type="text" id="username">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="password" class="col-md-1 col-form-label">Password</label>
                            <div class="col-md-11">
                                <input class="form-control" value="<?php echo e(old('password', $paymentData?->password)); ?>"
                                    placeholder="Password" name="password" type="text" id="password">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="app_key" class="col-md-1 col-form-label">App Key</label>
                            <div class="col-md-11">
                                <input class="form-control" value="<?php echo e(old('app_key', $paymentData?->app_key)); ?>"
                                    placeholder="App Key" name="app_key" type="text" id="app_key">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="secret_key" class="col-md-1 col-form-label">Secret Key</label>
                            <div class="col-md-11">
                                <input class="form-control" value="<?php echo e(old('secret_key', $paymentData?->secret_key)); ?>"
                                    placeholder="Secret Key" name="secret_key" type="text" id="secret_key">
                            </div>
                        </div>


                        <br>
                        <button type="submit" class="btn btn-success">Submit</button>
                    </form>

                </div>
            </div>
        </div> <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\__public\project\landing-page\resources\views/admin/pages/payment/configure.blade.php ENDPATH**/ ?>