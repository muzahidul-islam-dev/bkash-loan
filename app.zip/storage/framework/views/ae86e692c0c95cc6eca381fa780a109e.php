<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex gap-2 justify-content-between">
                        <h2 class="card-title">Services</h2>
                        <a href="<?php echo e(Route('service.add')); ?>" class="btn btn-success">Add Service</a>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($service->id); ?></th>
                                        <td><?php echo e($service->name); ?></td>
                                        <td><?php echo e($service->price); ?></td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <a href="<?php echo e(Route('service.edit', [$service->id])); ?>"
                                                    class="btn btn-success btn-sm">
                                                    Edit
                                                </a>
                                                <a href="<?php echo e(Route('service.delete', [$service->id])); ?>"
                                                    class="btn btn-danger btn-sm">
                                                    Delete
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\__public\project\landing-page\resources\views/admin/pages/service/all.blade.php ENDPATH**/ ?>